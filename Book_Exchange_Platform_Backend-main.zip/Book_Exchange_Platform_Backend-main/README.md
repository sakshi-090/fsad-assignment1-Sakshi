# Book Exchange Platform Backend
 Book Exchange Platform Backend built on Java, SpringBoot, Hibernate and MySQL.
