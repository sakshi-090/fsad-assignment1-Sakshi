package com.example.BookExchange.auth.memory;
import java.util.HashMap;
import java.util.Map;

import com.example.BookExchange.auth.model.Token;

public class Tokens {
	public static Map<String, Token> tokenMap = new HashMap<>();
}